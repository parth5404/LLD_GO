package main

import (
	"fmt"
	"time"
)

type OrderStatus int

const (
	Pending OrderStatus = iota
	Preparing
	Ready
	Completed
	Cancelled
)

func (s OrderStatus) String() string {
	switch s {
	case Pending:
		return "Pending"
	case Preparing:
		return "Preparing"
	case Ready:
		return "Ready"
	case Completed:
		return "Completed"
	case Cancelled:
		return "Cancelled"
	default:
		return "Unknown"
	}
}

var paymentfactory *PaymentFactory = NewPaymentFactory()
var publisher *Publisher = NewPublisher()

type Order struct {
	OrderStatus   OrderStatus
	PaymentStatus PaymentStatus
	CreatedAt     time.Time
	CancelUntil   time.Time
	Product       CoffeeItem
}

func CreateOrder(product CoffeeItem) *Order {
	now := time.Now()
	order := &Order{
		OrderStatus:   Pending,
		CreatedAt:     now,
		CancelUntil:   now.Add(5 * time.Minute),
		Product:       product,
		PaymentStatus: PendingP,
	}
	fmt.Println("Creating the Order", product.CoffeeItem())
	publisher.NotifyAll("Order Received")
	return order
}

func PayOrder(payType string, order *Order) *Order {
	start, _ := paymentfactory.GetPaymentInterface(payType)
	start.pay(order.Product)
	if payType != "COD" {
		order.PaymentStatus = PaidP
	}
	// TODO
	publisher.NotifyCustomer("Payment Processed")
	processOrder(order)
	return order
}

func CancelOrder(o *Order) error {
	if time.Now().After(o.CancelUntil) {
		return fmt.Errorf("Deadline over to cancel order")
	}
	o.OrderStatus = Cancelled
	return nil
}

func processOrder(o *Order) {
	publisher.NotifyCustomer("Order is Processing " + o.Product.CoffeeItem())
	time.Sleep(5 * time.Second)
	o.OrderStatus = Completed
	publisher.NotifyCustomer("Order is Made")
}
