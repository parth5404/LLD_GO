package main

import (
	"fmt"
	"time"
)

func main() {
	cfitemfactory := NewCoffeeFactory()

	publisher.AddObserver(
		NewCustomer("Alice"),
		NewKitchenDisplay("K1"),
		NewInventorySystem(),
	)

	finalitem, err := cfitemfactory.GetBaseCoffee("LATTE")
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	addons := []string{
		"milk",
		// "chocolate",
		"caramel",
	}

	for _, addon := range addons {
		modifier, err := GetAddon(addon)
		if err != nil {
			panic(err)
		}
		finalitem = modifier(finalitem)
	}

	// paymentStrategy, err := paymentfactory.GetPaymentInterface("UPI")
	// if err != nil {
	// 	fmt.Println("Error:", err)
	// 	return
	// }

	// paymentStrategy.pay(finalitem)
	order := CreateOrder(finalitem)
	PayOrder("UPI", order)
	time.Sleep(10 * time.Second)
}
